from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel
import joblib
import pandas as pd
import os
from datetime import timedelta

\1
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL_DIR = "models"


class ForecastRequest(BaseModel):
    commodity: str = "soybean"
    region: str = "Nagpur"
    days_ahead: int = 7


def load_bundle(commodity: str, region: str):
    filename = f"{commodity}_{region}_bundle.pkl"
    path = os.path.join(MODEL_DIR, filename)
    if not os.path.exists(path):
        raise RuntimeError(f"Model bundle not found for {commodity}-{region}. Train the model first.")
    return joblib.load(path)


def generate_forecast(commodity: str, region: str, days_ahead: int):
    bundle = load_bundle(commodity, region)

    price_model = bundle["price_model"]
    supply_model = bundle["supply_model"]
    demand_model = bundle["demand_model"]
    feature_cols = bundle["feature_cols"]
    last_row = bundle["last_row"].copy()

    df_future = last_row.reset_index(drop=True)
    predictions = []
    current_date = df_future.loc[0, "date"]

    for _ in range(days_ahead):
        current_date = current_date + timedelta(days=1)
        df_future.loc[0, "date"] = current_date

        df_future.loc[0, "dayofyear"] = current_date.timetuple().tm_yday
        df_future.loc[0, "month"] = current_date.month
        df_future.loc[0, "weekofyear"] = current_date.isocalendar()[1]

        X = df_future[feature_cols]

        pred_price = float(price_model.predict(X)[0])
        pred_supply = float(supply_model.predict(X)[0])
        pred_demand = float(demand_model.predict(X)[0])

        predictions.append({
            "date": current_date.strftime("%Y-%m-%d"),
            "price": round(pred_price, 2),
            "supply_arrivals_tonnes": round(pred_supply, 2),
            "demand_index": round(pred_demand, 3),
        })

        # Update basic state for next step
        df_future.loc[0, "price"] = pred_price
        df_future.loc[0, "arrivals_tonnes"] = pred_supply
        df_future.loc[0, "demand_index"] = pred_demand

        for col in ["price", "arrivals_tonnes", "demand_index"]:
            df_future.loc[0, f"{col}_lag1"] = df_future.loc[0, col]
            df_future.loc[0, f"{col}_lag7"] = df_future.loc[0, col]
            df_future.loc[0, f"{col}_lag30"] = df_future.loc[0, col]
            df_future.loc[0, f"{col}_roll7"] = df_future.loc[0, col]
            df_future.loc[0, f"{col}_roll30"] = df_future.loc[0, col]

    # Simple advisory
    if len(predictions) >= 2:
        start_price = predictions[0]["price"]
        end_price = predictions[-1]["price"]
        start_supply = predictions[0]["supply_arrivals_tonnes"]
        end_supply = predictions[-1]["supply_arrivals_tonnes"]
        start_demand = predictions[0]["demand_index"]
        end_demand = predictions[-1]["demand_index"]

        price_trend = "rising" if end_price > start_price else "falling or stable"
        supply_trend = "rising" if end_supply > start_supply else "falling or stable"
        demand_trend = "rising" if end_demand > start_demand else "falling or stable"

        advisory_parts = [
            f"Price trend: {price_trend}.",
            f"Supply trend: {supply_trend}.",
            f"Demand trend: {demand_trend}.",
        ]

        if demand_trend == "rising" and supply_trend != "rising":
            advisory_parts.append("Likely upward pressure on prices – farmers may benefit from holding or timing sales.")
        elif supply_trend == "rising" and demand_trend != "rising":
            advisory_parts.append("Oversupply risk – consider storage, processing or forward contracts.")
        else:
            advisory_parts.append("Market seems relatively balanced – monitor local conditions closely.")

        advisory = " ".join(advisory_parts)
    else:
        advisory = "Insufficient horizon for advisory."

    return predictions, advisory


@app.post("/forecast")
def forecast(req: ForecastRequest):
    preds, advisory = generate_forecast(req.commodity, req.region, req.days_ahead)
    return {
        "commodity": req.commodity,
        "region": req.region,
        "days_ahead": req.days_ahead,
        "forecast": preds,
        "advisory": advisory
    }
