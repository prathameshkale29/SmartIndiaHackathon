function WeatherWidget({ location }) {
  try {
    const [weatherData, setWeatherData] = React.useState(null);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);
    const [aiAlerts, setAiAlerts] = React.useState([]);

    const defaultLocation = {
      name: 'Wardha, Maharashtra',
      latitude: 20.7453,
      longitude: 78.6022
    };

    const activeLocation = location || defaultLocation;

    const buildPlantingAdvice = (data) => {
      if (!data || !data.current || !data.forecast || !data.forecast.length) {
        return null;
      }

      const { current, forecast } = data;
      const windowDays = forecast.slice(0, 3);

      const avgMaxTemp =
        windowDays.reduce((sum, d) => sum + (d.tempMax || d.temp), 0) /
        windowDays.length;
      const avgRain =
        windowDays.reduce((sum, d) => sum + (d.rain || 0), 0) /
        windowDays.length;

      const temp = current.temp;
      const rainToday = current.rainfall;
      const humidity = current.humidity;

      const scoreFromRange = (value, min, max) => {
        if (value >= min && value <= max) return 2;
        if (value >= min - 3 && value <= max + 3) return 1;
        return 0;
      };

      const rainScore = (r) => {
        if (r >= 0 && r <= 20) return 2;
        if (r > 20 && r <= 40) return 1;
        return 0;
      };

      const humidityScore = (h) => {
        if (h >= 50 && h <= 80) return 2;
        if (h >= 40 && h < 50) return 1;
        if (h > 80 && h <= 90) return 1;
        return 0;
      };

      const makeCropAdvice = (label, idealMin, idealMax, maxRain) => {
        const tempS = scoreFromRange(temp, idealMin, idealMax);
        const avgTempS = scoreFromRange(avgMaxTemp, idealMin, idealMax);
        const rainS = rainScore(Math.min(avgRain, maxRain));
        const humS = humidityScore(humidity);

        const total = tempS + avgTempS + rainS + humS;
        let level = 'Risky';
        let color = 'bg-red-100 text-red-700 border-red-300';
        let note = 'Conditions are not ideal. Consider waiting for a better window.';

        if (total >= 6) {
          level = 'Good';
          color = 'bg-emerald-100 text-emerald-700 border-emerald-300';
          note = 'Weather looks supportive for sowing in the next few days.';
        } else if (total >= 4) {
          level = 'Okay';
          color = 'bg-amber-100 text-amber-700 border-amber-300';
          note = 'Mixed conditions. You can sow with some caution and field judgement.';
        }

        return {
          crop: label,
          level,
          color,
          note
        };
      };

      const soybean = makeCropAdvice('Soybean', 20, 32, 35);
      const mustard = makeCropAdvice('Mustard', 15, 25, 25);
      const groundnut = makeCropAdvice('Groundnut', 22, 34, 30);
      const sunflower = makeCropAdvice('Sunflower', 18, 30, 30);

      const all = [soybean, mustard, groundnut, sunflower];
      const goodCount = all.filter((c) => c.level === 'Good').length;
      const riskyCount = all.filter((c) => c.level === 'Risky').length;

      let overall = 'Mixed';
      let overallColor = 'bg-amber-50 text-amber-700 border-amber-200';
      let overallText =
        'Some crops have a favourable window, while others may require caution. Check individual crop advisories.';

      if (goodCount >= 3 && riskyCount === 0) {
        overall = 'Good';
        overallColor = 'bg-emerald-50 text-emerald-700 border-emerald-200';
        overallText =
          'Overall, this is a good window for sowing oilseeds at this location.';
      } else if (riskyCount >= 3) {
        overall = 'Risky';
        overallColor = 'bg-red-50 text-red-700 border-red-200';
        overallText =
          'Overall conditions are not favourable for sowing. It may be better to wait.';
      }

      return {
        overall,
        overallColor,
        overallText,
        crops: all
      };
    };

    React.useEffect(() => {
      const fetchWeather = async () => {
        try {
          setLoading(true);
          setError(null);

          const latitude = activeLocation.latitude;
          const longitude = activeLocation.longitude;

          const url =
            'https://api.open-meteo.com/v1/forecast?latitude=' +
            latitude +
            '&longitude=' +
            longitude +
            '&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m' +
            '&daily=precipitation_sum,temperature_2m_max,temperature_2m_min' +
            '&timezone=auto';

          const response = await fetch(url);
          if (!response.ok) {
            throw new Error('Weather API error');
          }
          const data = await response.json();

          const current = {
            temp: data.current?.temperature_2m ?? 28,
            condition: 'Live data',
            humidity: data.current?.relative_humidity_2m ?? 60,
            windSpeed: data.current?.wind_speed_10m ?? 10,
            rainfall: data.current?.precipitation ?? 0
          };

          const forecast = (data.daily?.time || []).map((day, idx) => ({
            day,
            tempMax: data.daily.temperature_2m_max[idx],
            tempMin: data.daily.temperature_2m_min[idx],
            temp: data.daily.temperature_2m_max[idx],
            rain: data.daily.precipitation_sum[idx]
          }));

          const normalized = { current, forecast };
          const plantingAdvice = buildPlantingAdvice(normalized);

          setWeatherData({
            ...normalized,
            plantingAdvice
          });
          // Call local AI advisory service for weather alerts (FastAPI on port 8010)
          try {
            const advisoryRes = await fetch('http://localhost:8010/advisory/weather-alert', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                location: activeLocation.name,
                rain_24h: today.precipitation,
                wind_kmph: current.windSpeed,
                humidity_percent: current.humidity
              })
            });
            if (advisoryRes.ok) {
              const advisoryJson = await advisoryRes.json();
              if (advisoryJson && advisoryJson.alerts) {
                setAiAlerts(advisoryJson.alerts);
              }
            }
          } catch (e) {
            console.warn('Weather AI advisory error', e);
          }

        } catch (err) {
          console.error('Weather load failed', err);
          setError('Unable to load live weather. Showing sample data.');

          const sample = {
            current: {
              temp: 28,
              condition: 'Partly Cloudy',
              humidity: 65,
              windSpeed: 12,
              rainfall: 2
            },
            forecast: [
              { day: 'Today', temp: 28, tempMax: 30, tempMin: 24, rain: 5 },
              { day: 'Tomorrow', temp: 30, tempMax: 32, tempMin: 25, rain: 12 },
              { day: 'Day 3', temp: 29, tempMax: 31, tempMin: 24, rain: 8 },
              { day: 'Day 4', temp: 31, tempMax: 33, tempMin: 25, rain: 3 },
              { day: 'Day 5', temp: 27, tempMax: 29, tempMin: 23, rain: 15 }
            ]
          };

          setWeatherData({
            ...sample,
            plantingAdvice: buildPlantingAdvice(sample)
          });
        } finally {
          setLoading(false);
        }
      };

      fetchWeather();
    }, [activeLocation.latitude, activeLocation.longitude]);

    if (loading) {
      return (
        <div className="card" data-name="weather-widget" data-file="components/WeatherWidget.js">
          <p className="text-sm text-[var(--text-secondary)]">Loading live weather for your field...</p>
        </div>
      );
    }

    if (!weatherData) return null;

    const { current, forecast, plantingAdvice } = weatherData;

    return (
      <div className="card" data-name="weather-widget" data-file="components/WeatherWidget.js">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">Weather & Sowing Advisory</h3>
            <p className="text-sm text-[var(--text-secondary)]">
              Live weather for <span className="font-medium">{activeLocation.name}</span>
            </p>
            {error && (
              <p className="mt-1 text-xs text-amber-600">
                {error}
              </p>
            )}
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold">{Math.round(current.temp)}°C</p>
            <p className="text-xs text-[var(--text-secondary)]">
              Humidity {current.humidity}% · Wind {Math.round(current.windSpeed)} km/h
            </p>
            <p className="text-xs text-[var(--text-secondary)]">
              Rain (now) {current.rainfall} mm
            </p>
          </div>
        </div>

        {plantingAdvice && (
          <div className={"mb-4 p-3 rounded-xl border text-sm " + plantingAdvice.overallColor}>
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-semibold">
                  Overall sowing window: <span>{plantingAdvice.overall}</span>
                </p>
                <p className="text-xs mt-1">
                  {plantingAdvice.overallText}
                </p>
              </div>
              <div className="text-right text-xs">
                <p className="font-medium">Crops covered:</p>
                <p>Soybean · Mustard · Groundnut · Sunflower</p>
              </div>
            </div>
          </div>
        )}

        {plantingAdvice && (
          <div className="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
            {plantingAdvice.crops.map((crop) => (
              <div
                key={crop.crop}
                className={"border rounded-xl px-3 py-2 flex flex-col gap-1 " + crop.color}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold">{crop.crop}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/70 border">
                    {crop.level}
                  </span>
                </div>
                <p className="leading-snug">{crop.note}</p>
              </div>
            ))}
          </div>
        )}

        <div className="mt-2 pt-3 border-t border-[var(--border-light)]">
          <p className="text-xs font-semibold mb-2 text-[var(--text-secondary)]">
            Next 5 days outlook
          </p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {forecast.slice(0, 5).map((day, idx) => (
              <div
                key={idx}
                className="min-w-[80px] bg-[var(--bg-light)] rounded-lg p-2 text-center text-xs"
              >
                <p className="font-medium mb-1">
                  {day.day && typeof day.day === 'string' && day.day.includes('-')
                    ? new Date(day.day).toLocaleDateString(undefined, {
                        weekday: 'short',
                        day: 'numeric'
                      })
                    : day.day || 'Day ' + (idx + 1)}
                </p>
                <p className="text-lg font-semibold mb-1">
                  {Math.round(day.tempMax || day.temp)}°C
                </p>
                <p className="text-[var(--text-secondary)]">
                  {Math.round(day.rain || 0)} mm rain
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('WeatherWidget component error:', error);
    return null;
  }
}
