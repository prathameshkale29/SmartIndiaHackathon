function MarketTable() {
  try {
    const [marketData, setMarketData] = React.useState(mockData.marketPrices);
    const [refreshing, setRefreshing] = React.useState(false);

    const refreshPrices = () => {
      setRefreshing(true);
      setTimeout(() => {
        const updated = marketData.map(item => ({
          ...item,
          price: item.price + Math.floor(Math.random() * 200) - 100,
          change: (Math.random() * 6 - 3).toFixed(1)
        }));
        setMarketData(updated);
        setRefreshing(false);
      }, 1000);
    };

    return (
      <div className="card" data-name="market-table" data-file="components/MarketTable.js">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">{t('currentMarketPrices')}</h3>
          <button 
            onClick={refreshPrices}
            disabled={refreshing}
            className="btn-primary flex items-center gap-2"
          >
            <div className={`icon-refresh-cw text-lg ${refreshing ? 'animate-spin' : ''}`}></div>
            <span>{t('refresh')}</span>
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--border-color)]">
                <th className="text-left py-3 px-4 text-sm font-medium text-[var(--text-secondary)]">{t('region')}</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[var(--text-secondary)]">{t('crop')}</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[var(--text-secondary)]">{t('price')}</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[var(--text-secondary)]">{t('change')}</th>
              </tr>
            </thead>
            <tbody>
              {marketData.map((item, idx) => (
                <tr key={idx} className="border-b border-[var(--border-color)] hover:bg-[var(--bg-light)] transition-all duration-300">
                  <td className="py-3 px-4">{item.region}</td>
                  <td className="py-3 px-4">{item.crop}</td>
                  <td className="py-3 px-4 font-medium">₹{item.price}</td>
                  <td className="py-3 px-4">
                    <span className={`${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {item.change >= 0 ? '↑' : '↓'} {Math.abs(item.change)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  } catch (error) {
    console.error('MarketTable component error:', error);
    return null;
  }
}